package br.com.fiap.sprint3.service;

import org.springframework.ai.annotation.Model;
import org.springframework.stereotype.Service;

@Service
public class AiService {

    @Model("path/to/model.pb") // Atualize com o caminho real do modelo
    private TensorFlowModel model;

    public String makePrediction(double[] inputs) {
        return model.predict(inputs).toString();
    }
}