# sprint4-tdspj-springMVC

Integrantes:

Maria Luiza de Oliveira Lobo - 552169

Gabriel santos de almeida - 551774

Luana Duque - 550813

Leonardo Shoiti Araki - 98587



1. Testando Autenticação e Perfis com Spring Security
Acesse e teste as permissões de acordo com o perfil configurado:

URL para acessar:

Para usuários ADMIN: http://localhost:8080/admin
Para usuários USER: http://localhost:8080/user
Testando com diferentes perfis de usuário:

Acesse a URL /admin enquanto estiver autenticado com o perfil ADMIN.
Deve exibir a página de admin (status 200 OK).
Tente acessar /admin com o perfil USER.
Deve retornar status 403 Forbidden, já que apenas ADMIN tem permissão.
Realize o login via formulário de login padrão do Spring Security. Para isso, acesse uma URL protegida sem autenticação e você será redirecionado para o formulário.
Simulação manual:

No navegador, tente fazer login com os usuários e senhas configurados (user:password para USER e admin:password para ADMIN).
2. Testando Internacionalização
Para acessar a internacionalização, adicione o parâmetro lang na URL e verifique as mensagens exibidas de acordo com o idioma.

URL para acessar:
http://localhost:8080/greeting?lang=en (para inglês)
http://localhost:8080/greeting?lang=es (para espanhol)
Verificação manual:

Acesse a URL com lang=en e verifique se a mensagem retornada é: Hello, welcome!.
Acesse a URL com lang=es e verifique se a mensagem retornada é: Hola, ¡bienvenido!.
3. Testando a Produção e Consumo de Kafka
Para testar o Kafka, verifique se as mensagens estão sendo produzidas e consumidas conforme o esperado.

Teste de Produção de Mensagens:

Use o ProducerService para enviar uma mensagem ao Kafka.
Se estiver usando uma ferramenta como o Kafka CLI ou Kafka UI, verifique se a mensagem foi publicada no tópico configurado (my_topic).
Teste de Consumo de Mensagens:

Verifique os logs da aplicação para confirmar se o ConsumerService consumiu a mensagem corretamente.
No console ou no arquivo de log, você deve ver uma mensagem como Consumed message: Test message.
Simulação manual:

Se o Kafka estiver rodando localmente, publique uma mensagem manualmente no tópico usando o Kafka CLI:
bash
Copiar código
kafka-console-producer.sh --broker-list localhost:9092 --topic my_topic
Digite uma mensagem e verifique se o ConsumerService a consome.
4. Testando Monitoramento com Spring Boot Actuator
Para testar o monitoramento com o Actuator, acesse os endpoints de monitoramento habilitados.

URLs para acessar os endpoints de monitoramento:
http://localhost:8080/actuator/health (verifica o status de saúde da aplicação)
http://localhost:8080/actuator/info (exibe informações sobre a aplicação)
Verificação manual:

Abra o navegador ou use uma ferramenta como curl para acessar os endpoints.
Para health, você deve ver uma resposta JSON indicando status: "UP" se a aplicação estiver funcionando.
Para info, a resposta depende das configurações fornecidas no application.properties ou application.yml.
Exemplo de verificação com curl:

bash
Copiar código
curl http://localhost:8080/actuator/health
curl http://localhost:8080/actuator/info
5. Testando a Inteligência Artificial com Spring AI
Para testar a funcionalidade de IA, simule uma chamada ao serviço AiService e verifique se a previsão é retornada corretamente.

Simulação e teste de previsão:
Crie um endpoint que acione o método makePrediction() do AiService passando um array de valores de entrada.
Verifique se o modelo de IA retorna uma resposta. A resposta esperada deve estar no formato configurado, como uma string representando a previsão.
Exemplo de teste de acesso:

No controlador, crie um endpoint para acessar o modelo de IA:
java
Copiar código
@RestController
@RequestMapping("/ai")
public class AiController {

    private final AiService aiService;

    public AiController(AiService aiService) {
        this.aiService = aiService;
    }

    @GetMapping("/predict")
    public String predict(@RequestParam double[] inputs) {
        return aiService.makePrediction(inputs);
    }
}
URL para acessar a previsão:
http://localhost:8080/ai/predict?inputs=0.5,1.2 (exemplo de entrada)
Verificação manual:

No navegador ou usando curl, acesse o endpoint de previsão com diferentes entradas para validar se o modelo responde conforme esperado:
bash

curl "http://localhost:8080/ai/predict?inputs=0.5,1